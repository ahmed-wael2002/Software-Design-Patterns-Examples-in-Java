/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package stategydp2;

/**
 *
 * @author ayman
 */
public class StrategyMedium implements IDifficulty{

    @Override
    public void ExecuteNexxtStep() {
        System.out.println("stategydp2.StrategyMedium.ExecuteNexxtStep()");
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
